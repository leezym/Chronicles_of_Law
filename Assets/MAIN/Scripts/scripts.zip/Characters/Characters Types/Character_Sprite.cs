using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;

namespace CHARACTERS
{
    public class Character_Sprite : Character
    {
        private const string SPRITE_RENDERER_NAME = "Renderers";
        //private const string SPRITESHEET_DEFAULT_SHEETNAME = "Default";
        //private const char SPRITESHEET_TEXT_SPRITE_DELIMITTER = '-';
        public CanvasGroup rootCG => root.GetComponent<CanvasGroup>();

        public List<CharacterSpriteLayer> layers = new List<CharacterSpriteLayer>();

        private int _layersCount;
        public override int layersCount
        {
            get { return _layersCount; }
            set { _layersCount = value; }
        }

        public override bool isVisible
        {
            get { return isRevealing || rootCG.alpha == 1; }
            set { rootCG.alpha = value ? 1 : 0; }
        }

        public Character_Sprite(string name, CharacterConfigData config) : base(name, config)
        {
            rootCG.alpha = ENABLE_ON_START ? 1 : 0;
            GetLayers();

            Debug.Log($"Created Sprite Character: '{name}'");
        }

        private void GetLayers()
        {
            Transform rendererRoot = animator.transform.Find(SPRITE_RENDERER_NAME);
            layersCount = rendererRoot.transform.childCount;

            if(rendererRoot == null)
                return;
            
            for(int i = 0; i < layersCount; i++)
            {
                Transform child = rendererRoot.transform.GetChild(i);

                Image renderImage = child.GetComponentInChildren<Image>();

                if(renderImage != null)
                {
                    CharacterSpriteLayer layer = new CharacterSpriteLayer(renderImage, i);
                    layers.Add(layer);
                    child.name = $"Layer: {i}";
                }
            }
        }

        public void SetSprite(Sprite sprite, int layer = 0)
        {
            layers[layer].SetSprite(sprite);
        }

        public Sprite GetSprite(string spriteName)
        {
            if(config.sprites.Count > 0)
            {
                if(config.sprites.TryGetValue(spriteName, out Sprite sprite))
                    return sprite;
            }

            Debug.LogWarning($"Character '{name}' does not have a default asset art called '{spriteName}'");
            return null;
        }

        public Coroutine TransitionSprite(Sprite sprite, int layer = 0, float speed = 1)
        {
            CharacterSpriteLayer spriteLayer = layers[layer];

            return spriteLayer.TransitionSprite(sprite, speed);
        }

        public override IEnumerator ShowingOrHiding(bool show)
        {
            float targetAlpha = show ? 1f : 0;
            CanvasGroup self = rootCG;

            while(self.alpha != targetAlpha)
            {
                self.alpha = Mathf.MoveTowards(self.alpha, targetAlpha, 3f * Time.deltaTime);
                yield return null;
            }

            co_revealing = null;
            co_hiding = null;
        }

        public override void OnReceiveCastingExpression(int layer, string expression)
        {
            Sprite sprite = GetSprite(expression);

            if(sprite == null)
            {
                Debug.LogWarning($"Sprite '{expression}' could not be found for character '{name}'");
                return;
            }

            TransitionSprite(sprite, layer);
        }
    }
}