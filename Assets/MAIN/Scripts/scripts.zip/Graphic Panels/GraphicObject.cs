using System.Collections;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Video;

public class GraphicObject
{
    public const string NAME_FORMAT = "Graphic - [{0}]";
    public const string MATERIAL_PATH = "Materials/layerTransitionMaterial";
    private const string MATERIAL_FIELD_MAINTEX = "_MainTex";
    private const string MATERIAL_FIELD_BLEND = "_Blend";
    private const string MATERIAL_FIELD_ALPHA = "_Alpha";
    public RawImage renderer;

    private GraphicLayer layer;

    public bool isVideo => video != null;
    public bool hasEnded { get; set; }
    public bool useAudio => (audio != null ? !audio.mute : false);
    public System.Action Finished;
    public VideoPlayer video = null;
    public AudioSource audio = null;

    public string graphicPath = "";
    public string graphicName { get; private set; }

    private Coroutine co_fadingIn = null;
    private Coroutine co_fadingOut = null;

    public GraphicObject(GraphicLayer layer, string graphicPath, Texture tex)
    {
        this.graphicPath = graphicPath;
        this.layer = layer;

        GameObject ob = new GameObject();
        ob.transform.SetParent(layer.panel);
        renderer = ob.AddComponent<RawImage>();

        graphicName = tex.name;

        InitGraphic();

        renderer.name = string.Format(NAME_FORMAT, graphicName);
        renderer.material.SetTexture(MATERIAL_FIELD_MAINTEX, tex);
    }

    public GraphicObject(GraphicLayer layer, string graphicPath, VideoClip clip, bool useAudio, bool loop, AudioBus bus)
    {
        hasEnded = false;
        this.graphicPath = graphicPath;
        this.layer = layer;

        GameObject ob = new GameObject();
        ob.transform.SetParent(layer.panel);
        renderer = ob.AddComponent<RawImage>();

        graphicName = clip.name;
        renderer.name = string.Format(NAME_FORMAT, graphicName);

        InitGraphic();

        RenderTexture tex = new RenderTexture(Mathf.RoundToInt(clip.width), Mathf.RoundToInt(clip.height), 0);
        renderer.material.SetTexture(MATERIAL_FIELD_MAINTEX, tex);

        video = renderer.AddComponent<VideoPlayer>();
        video.playOnAwake = true;
        video.source = VideoSource.VideoClip;
        video.clip = clip;
        video.renderMode = VideoRenderMode.RenderTexture;
        video.targetTexture = tex;
        video.isLooping = loop;

        video.audioOutputMode = VideoAudioOutputMode.AudioSource;
        audio = video.AddComponent<AudioSource>(); 

        audio.outputAudioMixerGroup = AudioManager.Instance.GetMixerGroup(bus);
        audio.volume = 0;

        if(!useAudio)
            audio.mute = true;
        
        video.SetTargetAudioSource(0, audio);
        video.loopPointReached += OnVideoEnded;

        video.frame = 0;
        video.Prepare();
        video.Play();

        video.enabled = false;
        video.enabled = true;
    }

    public void Restart()
    {
        if (!isVideo || video == null) return;

        hasEnded = false;
        video.frame = 0;
        video.Play();
        audio?.Play();
    }

    private void OnVideoEnded(VideoPlayer vp)
    {
        if (vp.isLooping) return;
        
        hasEnded = true;

        // Congelar en el último frame (1)
        long lastFrame = (vp.frameCount > 0) ? (long)vp.frameCount - 1 : vp.frame;
        vp.frame = lastFrame;
        vp.Pause();

        if (audio != null) audio.Pause();
        
        Finished?.Invoke();
    }

    private void InitGraphic()
    {
        renderer.transform.localPosition = Vector3.zero;
        renderer.transform.localScale = Vector3.one;

        RectTransform rect = renderer.GetComponent<RectTransform>();
        rect.anchorMin = Vector2.zero;
        rect.anchorMax = Vector2.one;
        rect.offsetMin = Vector2.zero;
        rect.offsetMax = Vector2.one;

        renderer.material = GetTransitionMaterial();

        renderer.material.SetFloat(MATERIAL_FIELD_BLEND, 0);
        renderer.material.SetFloat(MATERIAL_FIELD_ALPHA, 0);
    }

    private Material GetTransitionMaterial()
    {
        return Resources.Load<Material>(MATERIAL_PATH);
    }

    GraphicPanelManager panelManager => GraphicPanelManager.Instance;

    public Coroutine FadeIn(float speed = 1f)
    {
        if(co_fadingOut != null)
            panelManager.StopCoroutine(co_fadingOut);

        if(co_fadingIn != null)
            return co_fadingIn;
        
        co_fadingIn = panelManager.StartCoroutine(Fading(1f, speed));

        return co_fadingIn;
    }

    public Coroutine FadeOut(float speed = 1f)
    {
        if(co_fadingIn != null)
            panelManager.StopCoroutine(co_fadingIn);

        if(co_fadingOut != null)
            return co_fadingOut;
        
        co_fadingOut = panelManager.StartCoroutine(Fading(0f, speed));

        return co_fadingOut;
    }

    private IEnumerator Fading(float target, float speed)
    {
        bool fadingIn = target > 0;

        renderer.material.SetFloat(MATERIAL_FIELD_ALPHA, fadingIn ? 0 : 1);
        renderer.material.SetFloat(MATERIAL_FIELD_BLEND, 1);

        string opacityParam = MATERIAL_FIELD_ALPHA;

        while(renderer.material.GetFloat(opacityParam) != target)
        {
            float opacity = Mathf.MoveTowards(renderer.material.GetFloat(opacityParam), target, speed * Time.deltaTime);
            renderer.material.SetFloat(opacityParam, opacity);

            if(isVideo)
                audio.volume = opacity;

            yield return null;
        }

        co_fadingIn = null;
        co_fadingOut = null;

        if(target == 0)
            Destroy();
        else
        {
            DestroyBackgroundGraphicsOnLayer();
            renderer.texture = renderer.material.GetTexture(MATERIAL_FIELD_MAINTEX);
            renderer.material = null;
        } 
    }

    private void Destroy()
    {
        if(layer.currentGraphic != null && layer.currentGraphic.renderer == renderer)
            layer.currentGraphic = null;
        
        if(layer.oldGraphics.Contains(this))
            layer.oldGraphics.Remove(this);
        
        Object.Destroy(renderer.gameObject);
    }

    private void DestroyBackgroundGraphicsOnLayer()
    {
        layer.DestroyOldGraphics();
    }
}
