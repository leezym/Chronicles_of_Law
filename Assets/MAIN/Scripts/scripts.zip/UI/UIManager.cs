using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIManager : MonoBehaviour
{
    public static UIManager Instance { get; private set; }

    public Button continueButton;

    [Header("Comportamiento")]
    [Tooltip("Si está activo, oculta el menú anterior al abrir uno nuevo.")]
    [SerializeField] private bool autoHidePrevious = true;

    [Tooltip("Menú que se abre al inicio del juego.")]
    [SerializeField] private MenuType initialMenu = MenuType.Main;

    private readonly Dictionary<MenuType, UIMenu> menus = new();
    private readonly Stack<MenuType> history           = new();

    public MenuType? CurrentMenu { get; private set; }

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
        RegisterMenus();
    }

    private void Start()
    {
        ShowMenu(initialMenu, instant: true);
    }

    private void RegisterMenus()
    {
        menus.Clear();

        foreach (var menu in GetComponentsInChildren<UIMenu>(includeInactive: true))
        {
            if (menus.ContainsKey(menu.menuType))
            {
                Debug.LogWarning($"[UIManager] Menú duplicado: {menu.menuType}. Se ignorará '{menu.name}'.");
                continue;
            }

            menus[menu.menuType] = menu;
        }
    }

    public void ShowMenu(MenuType type, bool instant = false, bool saveToHistory = true)
    {
        if (!menus.TryGetValue(type, out UIMenu target))
        {
            Debug.LogError($"[UIManager] No se encontró el menú '{type}'.");
            return;
        }

        if (CurrentMenu.HasValue && CurrentMenu.Value == type)
            return;

        // Ocultar el menú actual
        if (autoHidePrevious && CurrentMenu.HasValue)
        {
            if (menus.TryGetValue(CurrentMenu.Value, out UIMenu current))
                current.Hide(instant);
        }

        // Guardar historial
        if (saveToHistory && CurrentMenu.HasValue)
            history.Push(CurrentMenu.Value);

        CurrentMenu = type;
        target.Show(instant);
    }

    public void GoBack(bool instant = false)
    {
        if (history.Count == 0)
        {
            Debug.LogWarning("[UIManager] No hay historial de menús al que volver.");
            return;
        }

        MenuType previous = history.Pop();
        ShowMenu(previous, instant, saveToHistory: false);
    }

    public void HideAll(bool instant = false)
    {
        foreach (var menu in menus.Values)
            menu.Hide(instant);

        CurrentMenu = null;
        history.Clear();
    }

    public void TogglePause()
    {
        if (!menus.TryGetValue(MenuType.Pause, out UIMenu pauseMenu))
            return;

        if (pauseMenu.IsVisible)
        {
            Time.timeScale = 1;
            pauseMenu.Hide();
            return;
        }

        foreach (var kvp in menus)
        {
            if (kvp.Key != MenuType.Pause && kvp.Value.IsVisible)
            {
                Debug.LogWarning($"[UIManager] No se puede pausar mientras '{kvp.Key}' está visible.");
                return;
            }
        }

        Time.timeScale = 0;
        pauseMenu.Show();
    }

    public bool IsMenuVisible(MenuType type)
    {
        return menus.TryGetValue(type, out UIMenu menu) && menu.IsVisible;
    }
}