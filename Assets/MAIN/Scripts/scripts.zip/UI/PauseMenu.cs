using UnityEngine;

public class PauseMenu : UIMenu
{
    protected override void OnShow()
    {
        PauseAllMedia();
        Time.timeScale = 0f; // al final
    }

    protected override void OnHide()
    {
        Time.timeScale = 1f; // al inicio
        ResumeAllMedia();
    }

    private void PauseAllMedia()
    {
        foreach (var panel in GraphicPanelManager.Instance.allPanels)
        {
            foreach (var layer in panel.layers)
            {
                var graphic = layer.currentGraphic;
                if (graphic == null) continue;

                if (graphic.isVideo)
                {
                    graphic.video?.Pause();
                    graphic.audio?.Pause();
                }
            }
        }

        AudioManager.Instance.Pause();
    }

    private void ResumeAllMedia()
    {
        foreach (var panel in GraphicPanelManager.Instance.allPanels)
        {
            foreach (var layer in panel.layers)
            {
                var graphic = layer.currentGraphic;
                if (graphic == null) continue;

                if (graphic.isVideo && !graphic.hasEnded)
                {
                    graphic.video?.Play();
                    graphic.audio?.Play();
                }
            }
        }

        AudioManager.Instance.Resume();
    }

    public void OnResumePressed()   => UIManager.Instance.TogglePause();
    public void OnMainMenuPressed() => UIManager.Instance.ShowMenu(MenuType.Main);
}