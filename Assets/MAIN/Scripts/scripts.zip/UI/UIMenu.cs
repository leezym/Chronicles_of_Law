using System.Collections;
using UnityEngine;

public enum MenuType { Main, CharacterSelector, Final, Pause }

[RequireComponent(typeof(CanvasGroup))]
public class UIMenu : MonoBehaviour
{
    [Header("Config")]
    public MenuType menuType;
    [SerializeField] private float transitionSpeed = 5f;

    private CanvasGroup canvasGroup;
    private Coroutine transitionCoroutine;

    public bool IsVisible => canvasGroup.alpha > 0f;

    protected virtual void Awake()
    {
        canvasGroup = GetComponent<CanvasGroup>();
        SetVisibility(false, instant: true);
    }

    protected virtual void OnShow() { }
    protected virtual void OnHide() { }

    public void Show(bool instant = false)
    {
        gameObject.SetActive(true);
        OnShow();
        Transition(1f, instant);
    }

    public void Hide(bool instant = false)
    {
        if (!gameObject.activeSelf)
            return;

        OnHide();
        Transition(0f, instant, deactivateOnEnd: true);
    }

    private void SetVisibility(bool visible, bool instant)
    {
        float target = visible ? 1f : 0f;

        canvasGroup.alpha          = instant ? target : canvasGroup.alpha;
        canvasGroup.interactable   = visible;
        canvasGroup.blocksRaycasts = visible;

        if (!visible && instant)
            gameObject.SetActive(false);
    }

    private void Transition(float target, bool instant, bool deactivateOnEnd = false)
    {
        if (transitionCoroutine != null)
            StopCoroutine(transitionCoroutine);

        if (instant)
        {
            canvasGroup.alpha          = target;
            canvasGroup.interactable   = target > 0f;
            canvasGroup.blocksRaycasts = target > 0f;

            if (deactivateOnEnd && target == 0f)
                gameObject.SetActive(false);

            return;
        }

        transitionCoroutine = StartCoroutine(FadeRoutine(target, deactivateOnEnd));
    }

    private IEnumerator FadeRoutine(float target, bool deactivateOnEnd)
    {
        canvasGroup.interactable   = false;
        canvasGroup.blocksRaycasts = false;

        while (!Mathf.Approximately(canvasGroup.alpha, target))
        {
            canvasGroup.alpha = Mathf.MoveTowards(canvasGroup.alpha, target, transitionSpeed * Time.unscaledDeltaTime);
            yield return null;
        }

        canvasGroup.alpha = target;

        bool isShowing = target > 0f;
        canvasGroup.interactable   = isShowing;
        canvasGroup.blocksRaycasts = isShowing;

        if (deactivateOnEnd && !isShowing)
            gameObject.SetActive(false);

        transitionCoroutine = null;
    }
}