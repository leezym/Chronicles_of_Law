using System.Collections.Generic;
using TMPro;
using UnityEngine;
namespace GAME
{
    public class GameManager : MonoBehaviour
    {
        public static GameManager Instance { get; private set; }

        public TMP_Text pointsText;
        float points { get; set; } = 0f;
        int currentCaseLevel { get; set; } = 0;
        int currentGameLevel { get; set; } = 0;
        int currentLevel { get; set; } = 1;

        [SerializeField] public List<Items> items = new List<Items>();
        
        public enum Gender {F, M}
        [field: SerializeField] public Gender currentGameGender { get; private set; }

        private void Awake()
        {
            Instance = this;
        }

        public float GetPoints(){ return points; }

        public void SetPoints(float points)
        {
            this.points += points;
            pointsText.text = this.points.ToString();
        }

        public int GetCurrentCaseLevel(){ return currentCaseLevel; }

        public void SetCurrentCaseLevel(int currentCaseLevel)
        {
            this.currentCaseLevel = currentCaseLevel;
        }

        public void IncreaseCurrentCaseLevel()
        {
            currentCaseLevel ++;
        }

        public int GetCurrentGameLevel(){ return currentGameLevel; }

        public void SetCurrentGameLevel(int currentGameLevel)
        {
            this.currentGameLevel = currentGameLevel;
        }

        public void IncreaseCurrentGameLevel()
        {
            currentGameLevel ++;
        }

        public int GetCurrentLevel(){ return currentLevel; }

        public void SetCurrentLevel(int currentLevel)
        {
            this.currentLevel = currentLevel;
        }

        public void IncreaseCurrentLevel()
        {
            currentLevel ++;
        }

        public Gender GetCurrentGender(){ return currentGameGender; }

        public void SetGenderF() => currentGameGender = Gender.F;
        public void SetGenderM() => currentGameGender = Gender.M;
    }
}