using System;
using System.Collections;
using System.Collections.Generic;
using HISTORY;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UI;
using VISUALNOVEL;

namespace DIALOGUE
{
    public class PlayerInputManager : MonoBehaviour
    {
        static float MINIMUN_VOL = 0.0001f;
        static float MAXIMUN_VOL = 1f;
        float currentVol;
        public Slider sliderVolume;
        private PlayerInput input;
        private List<(InputAction action, Action<InputAction.CallbackContext> command)> actions = new List<(InputAction action, Action<InputAction.CallbackContext> command)>(); 

        void Awake()
        {
            input = GetComponent<PlayerInput>();
            InitializeActions();
        }

        void InitializeActions()
        {
            actions.Add((input.actions["Mute"], Mute));
            actions.Add((input.actions["Next"], PromptAdvance));
            actions.Add((input.actions["Pause"], Pause));
        }

        private void OnEnable()
        {
            foreach (var inputAction in actions)
                inputAction.action.performed += inputAction.command;
        }

         private void OnDisable()
        {
            foreach (var inputAction in actions)
                inputAction.action.performed -= inputAction.command;
        }

        public void Mute(InputAction.CallbackContext c)
        {
            sliderVolume.value = sliderVolume.value == MINIMUN_VOL ? currentVol : MINIMUN_VOL;
        }

        public void SetVolume()
        {
            currentVol = sliderVolume.value > MINIMUN_VOL ? sliderVolume.value : MAXIMUN_VOL;

            AudioManager.Instance.SetVolume(sliderVolume.value);
        }
        public void PromptAdvance(InputAction.CallbackContext c)
        {
            PromptAdvance();
        }

        public void PromptAdvance()
        {
            if (!FolderPanel.Instance.isWaitingOnUserChoice)
                DialogueSystem.Instance.OnUserPrompt_Next();
        }

        public void Pause(InputAction.CallbackContext c)
        {
            UIManager.Instance.TogglePause();
        }
    }
}

